<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class employment extends Model
{
    protected $table='employments';
    use HasFactory;
}
