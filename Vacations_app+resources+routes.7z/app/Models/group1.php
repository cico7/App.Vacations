<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class group1 extends Model
{
    protected $table='groups1';
    use HasFactory;
}
